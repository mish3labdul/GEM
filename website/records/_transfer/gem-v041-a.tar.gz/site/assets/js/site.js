/* GEM website · site behaviour · v0.4
   Progressive enhancement: the page works without this file. Each feature is installed in its
   own guarded block and only switches its UI on after its handlers are in place.
   - Navigation disclosure (compact to tablet widths)       — audit GEM-02
   - Enquiry form: fail-closed preparation (no native submit) — GEM-01
     stale-draft invalidation                                — GEM-04
   - Header: stays reachable on long pages (hides while reading down, returns on scroll up)
   - Section links: "you are here" marking in the navigation (aria-current="location")
   - Section calls to action preselect the enquiry topic
   - Delivery: OFF. No receiving destination is configured. See DELIVERY below.
   No network request is made by this file. */
(function () {
  "use strict";

  /* ---------- Navigation disclosure ---------- */
  try {
    var header = document.querySelector(".site-header");
    var toggle = header && header.querySelector(".nav-toggle");
    var nav = document.getElementById("primary-nav");
    if (header && toggle && nav) {
      var setOpen = function (open) {
        header.classList.toggle("is-open", open);
        toggle.setAttribute("aria-expanded", String(open));
        toggle.textContent = open ? "Close" : "Menu";
      };
      toggle.addEventListener("click", function () { setOpen(toggle.getAttribute("aria-expanded") !== "true"); });
      nav.addEventListener("click", function (e) { if (e.target.closest("a")) setOpen(false); });
      /* Close when the visitor taps outside the menu (including the scrim) or tabs out of it. */
      document.addEventListener("click", function (e) {
        if (toggle.getAttribute("aria-expanded") === "true" && !nav.contains(e.target) && !toggle.contains(e.target)) setOpen(false);
      });
      header.addEventListener("focusout", function (e) {
        if (toggle.getAttribute("aria-expanded") === "true" && e.relatedTarget && !header.contains(e.relatedTarget)) setOpen(false);
      });
      document.addEventListener("keydown", function (e) {
        if (e.key === "Escape" && toggle.getAttribute("aria-expanded") === "true") { setOpen(false); toggle.focus(); }
      });
      var mq = window.matchMedia("(min-width: 1024px)");
      var onMq = function () { if (mq.matches) setOpen(false); };
      if (mq.addEventListener) mq.addEventListener("change", onMq); else if (mq.addListener) mq.addListener(onMq);
      /* Handlers are installed: only now collapse the list behind the button. */
      toggle.hidden = false;
      header.classList.add("nav-ready");
    }
  } catch (err) {
    /* Leave the always-visible navigation in place. */
  }

  /* ---------- Header that stays reachable (audit C2) ----------
     CSS makes the header sticky only where the viewport is tall enough (see site.css). Here it
     steps out of the way while the visitor reads down and comes back as soon as they scroll up.
     Opacity only, per the motion rules; reduced motion makes it instant. */
  try {
    var hdr = document.querySelector(".site-header");
    if (hdr && window.matchMedia) {
      var tall = window.matchMedia("(min-height: 560px)");
      var root = document.documentElement;
      var setH = function () { root.style.setProperty("--header-h", (tall.matches ? hdr.offsetHeight : 0) + "px"); };
      setH();
      window.addEventListener("resize", setH);
      var lastY = window.scrollY, ticking = false;
      var update = function () {
        ticking = false;
        var y = window.scrollY;
        var keep = !tall.matches || y < hdr.offsetHeight || hdr.classList.contains("is-open") || hdr.contains(document.activeElement);
        if (keep || y < lastY - 4) hdr.classList.remove("is-tucked");
        else if (y > lastY + 4) hdr.classList.add("is-tucked");
        lastY = y;
      };
      window.addEventListener("scroll", function () { if (!ticking) { ticking = true; window.requestAnimationFrame(update); } }, { passive: true });
      hdr.addEventListener("focusin", function () { hdr.classList.remove("is-tucked"); });
    }
  } catch (err) { /* the header simply stays in place */ }

  /* ---------- "You are here" in section navigation (audit I5) ---------- */
  try {
    if ("IntersectionObserver" in window) {
      var groups = [document.querySelectorAll('#primary-nav a[href^="#"]'), document.querySelectorAll('.ref-toc a[href^="#"]')];
      groups.forEach(function (links) {
        if (!links.length) return;
        var byId = {};
        Array.prototype.forEach.call(links, function (a) { var t = document.getElementById(a.getAttribute("href").slice(1)); if (t) byId[t.id] = a; });
        var mark = function (id) {
          Array.prototype.forEach.call(links, function (a) { a.removeAttribute("aria-current"); });
          if (id && byId[id]) byId[id].setAttribute("aria-current", "location");
        };
        var visible = {};
        var io = new IntersectionObserver(function (entries) {
          entries.forEach(function (en) { visible[en.target.id] = en.isIntersecting; });
          var current = null;
          Object.keys(byId).forEach(function (id) { if (visible[id] && !current) current = id; });
          mark(current);
        }, { rootMargin: "-35% 0px -60% 0px" });
        Object.keys(byId).forEach(function (id) { io.observe(document.getElementById(id)); });
      });
    }
  } catch (err) { /* navigation still works without the marker */ }

  /* ---------- Section calls to action choose the enquiry topic (audit C2) ---------- */
  try {
    document.addEventListener("click", function (e) {
      var a = e.target.closest && e.target.closest("a[data-interest]");
      if (!a) return;
      var radio = document.getElementById(a.getAttribute("data-interest"));
      if (radio && !radio.checked) {
        radio.checked = true;
        /* Fire change so an existing draft is withdrawn (GEM-04). */
        radio.dispatchEvent(new Event("change", { bubbles: true }));
      }
    });
  } catch (err) { /* the link still goes to the form */ }

  /* ---------- Enquiry form ---------- */
  var form = document.getElementById("enquiry-form");
  if (!form) return;

  /* Installed first and unconditionally: no path through this script submits natively. */
  form.addEventListener("submit", function (e) { e.preventDefault(); });

  try {
    /* DELIVERY — switched off. To connect a destination later (separate authorization required):
       set endpoint to an HTTPS URL that accepts JSON and returns 2xx on success. Until then the
       form only prepares a local draft and says so. */
    var DELIVERY = { endpoint: "" };
    /* Interim hand-off (audit C1): when GEM supplies a real, monitored address, put it here and
       the drafted enquiry gains an "Open in your email app" button. Empty = hidden. Never use a
       placeholder or third-party address. */
    DELIVERY.mailto = "mish3labdul@gmail.com"; /* owner-supplied enquiry address, 2026-10-11 (WD-12) */

    var $ = function (id) { return document.getElementById(id); };
    var prepareButton = $("prepare-button");
    var unavailable = $("form-unavailable");
    var summary = $("error-summary");
    var list = $("error-list");
    var result = $("form-result");
    var output = $("f-output");
    var copyBtn = $("copy-output");
    var copyStatus = $("copy-status");
    var emailOut = $("email-output");
    var draftStatus = $("draft-status");
    var trap = $("f-website");
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    var hasDraft = false;

    var rules = [
      { id: "f-name", test: function (v) { return v.trim() !== ""; }, msg: "Enter your name." },
      { id: "f-email", test: function (v) { return emailPattern.test(v.trim()); }, msg: "Enter an email address in the format name@example.com." },
      { id: "f-interest", radio: "interest", msg: "Choose what your enquiry is about." },
      { id: "f-message", test: function (v) { return v.trim() !== ""; }, msg: "Tell us a little about your property or project." }
    ];
    var controlsFor = function (rule) {
      return rule.radio ? Array.prototype.slice.call(form.querySelectorAll('input[name="' + rule.radio + '"]')) : [$(rule.id)];
    };

    var setFieldError = function (rule, message) {
      var err = $(rule.id + "-error");
      controlsFor(rule).forEach(function (c) {
        /* Keep any help text in the description and add the error after it (Part B Field). */
        if (!c.hasAttribute("data-describedby")) c.setAttribute("data-describedby", c.getAttribute("aria-describedby") || "");
        var base = c.getAttribute("data-describedby");
        if (message) {
          c.setAttribute("aria-invalid", "true");
          if (!rule.radio) c.setAttribute("aria-describedby", (base ? base + " " : "") + rule.id + "-error");
        } else {
          c.removeAttribute("aria-invalid");
          if (!rule.radio) { if (base) c.setAttribute("aria-describedby", base); else c.removeAttribute("aria-describedby"); }
        }
      });
      err.textContent = message || "";
      err.hidden = !message;
    };

    var validate = function () {
      var errors = [];
      rules.forEach(function (rule) {
        var ok = rule.radio ? !!form.querySelector('input[name="' + rule.radio + '"]:checked') : rule.test($(rule.id).value);
        setFieldError(rule, ok ? "" : rule.msg);
        if (!ok) errors.push(rule);
      });
      return errors;
    };

    var value = function (name) { var el = form.elements[name]; return el ? String(el.value || "").trim() : ""; };
    var compose = function () {
      var interest = form.querySelector('input[name="interest"]:checked');
      return [
        "Enquiry for GEM",
        "Name: " + value("name"),
        "Email: " + value("email"),
        "Organisation or property: " + (value("organisation") || "Not given"),
        "About: " + (interest ? interest.value : ""),
        "",
        value("message")
      ].join("\n");
    };

    var clearDraft = function () {
      result.hidden = true;
      output.value = "";
      copyStatus.textContent = "";
      if (emailOut) { emailOut.hidden = true; emailOut.removeAttribute("href"); }
      hasDraft = false;
    };

    /* GEM-04: any edit after preparing withdraws the draft, so a stale copy cannot be taken. */
    var onEdit = function (e) {
      if (e.target === trap || e.target === output) return;
      if (hasDraft) {
        clearDraft();
        draftStatus.textContent = "Your details changed. Draft the enquiry again to update it.";
      }
    };
    form.addEventListener("input", onEdit);
    form.addEventListener("change", onEdit);

    form.addEventListener("submit", function () {
      clearDraft();
      draftStatus.textContent = "";
      var errors = validate();
      if (errors.length) {
        list.innerHTML = "";
        errors.forEach(function (rule) {
          var target = controlsFor(rule)[0];
          var li = document.createElement("li");
          var a = document.createElement("a");
          a.href = "#" + target.id;
          a.textContent = rule.msg;
          a.addEventListener("click", function (ev) { ev.preventDefault(); target.focus(); });
          li.appendChild(a);
          list.appendChild(li);
        });
        summary.hidden = false;
        controlsFor(errors[0])[0].focus();
        return;
      }
      summary.hidden = true;
      if (trap && trap.value) return; /* automated fill: do nothing */
      /* DELIVERY.endpoint is empty, so nothing is sent. */
      output.value = compose();
      if (emailOut && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(DELIVERY.mailto) && !/\.(example|invalid|test)$/i.test(DELIVERY.mailto)) {
        emailOut.setAttribute("href", "mailto:" + DELIVERY.mailto + "?subject=" + encodeURIComponent("Enquiry for GEM") + "&body=" + encodeURIComponent(output.value));
        emailOut.hidden = false;
      }
      hasDraft = true;
      result.hidden = false;
      result.focus();
    });

    form.addEventListener("reset", function () {
      rules.forEach(function (rule) { setFieldError(rule, ""); });
      summary.hidden = true;
      clearDraft();
      draftStatus.textContent = "";
      setTimeout(function () { $("f-name").focus(); }, 0);
    });

    copyBtn.addEventListener("click", function () {
      if (!hasDraft) return;
      var done = function () { copyStatus.textContent = "Copied to your clipboard."; };
      var fail = function () { output.focus(); output.select(); copyStatus.textContent = "Copy is not available here. The text is selected; copy it with your keyboard."; };
      try {
        if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(output.value).then(done, fail);
        else fail();
      } catch (err) { fail(); }
    });

    if (DELIVERY.endpoint) { /* reserved for an authorized connection; intentionally unused */ }

    /* Everything is installed: switch the form on. */
    unavailable.hidden = true;
    prepareButton.disabled = false;
  } catch (err) {
    /* Initialization failed: the button stays disabled and the unavailable notice stays visible. */
  }
})();
