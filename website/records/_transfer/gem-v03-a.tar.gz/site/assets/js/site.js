/* GEM website · site behaviour · v0.2
   Progressive enhancement: the page works without this file. Each feature is installed in its
   own guarded block and only switches its UI on after its handlers are in place.
   - Navigation disclosure (compact to tablet widths)       — audit GEM-02
   - Enquiry form: fail-closed preparation (no native submit) — GEM-01
     stale-draft invalidation                                — GEM-04
   - Delivery: OFF. No receiving destination is configured. See DELIVERY below.
   No network request is made by this file. */
(function () {
  "use strict";

  /* ---------- Navigation disclosure ---------- */
  try {
    var header = document.querySelector(".site-header");
    var toggle = header && header.querySelector(".nav-toggle");
    var nav = document.getElementById("primary-nav");
    if (header && toggle && nav) {
      var setOpen = function (open) {
        header.classList.toggle("is-open", open);
        toggle.setAttribute("aria-expanded", String(open));
        toggle.textContent = open ? "Close" : "Menu";
      };
      toggle.addEventListener("click", function () { setOpen(toggle.getAttribute("aria-expanded") !== "true"); });
      nav.addEventListener("click", function (e) { if (e.target.closest("a")) setOpen(false); });
      document.addEventListener("keydown", function (e) {
        if (e.key === "Escape" && toggle.getAttribute("aria-expanded") === "true") { setOpen(false); toggle.focus(); }
      });
      var mq = window.matchMedia("(min-width: 1024px)");
      var onMq = function () { if (mq.matches) setOpen(false); };
      if (mq.addEventListener) mq.addEventListener("change", onMq); else if (mq.addListener) mq.addListener(onMq);
      /* Handlers are installed: only now collapse the list behind the button. */
      toggle.hidden = false;
      header.classList.add("nav-ready");
    }
  } catch (err) {
    /* Leave the always-visible navigation in place. */
  }

  /* ---------- Enquiry form ---------- */
  var form = document.getElementById("enquiry-form");
  if (!form) return;

  /* Installed first and unconditionally: no path through this script submits natively. */
  form.addEventListener("submit", function (e) { e.preventDefault(); });

  try {
    /* DELIVERY — switched off. To connect a destination later (separate authorization required):
       set endpoint to an HTTPS URL that accepts JSON and returns 2xx on success. Until then the
       form only prepares a local draft and says so. */
    var DELIVERY = { endpoint: "" };

    var $ = function (id) { return document.getElementById(id); };
    var prepareButton = $("prepare-button");
    var unavailable = $("form-unavailable");
    var summary = $("error-summary");
    var list = $("error-list");
    var result = $("form-result");
    var output = $("f-output");
    var copyBtn = $("copy-output");
    var copyStatus = $("copy-status");
    var draftStatus = $("draft-status");
    var trap = $("f-website");
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    var hasDraft = false;

    var rules = [
      { id: "f-name", test: function (v) { return v.trim() !== ""; }, msg: "Enter your name." },
      { id: "f-email", test: function (v) { return emailPattern.test(v.trim()); }, msg: "Enter an email address in the format name@example.com." },
      { id: "f-interest", radio: "interest", msg: "Choose what your enquiry is about." },
      { id: "f-message", test: function (v) { return v.trim() !== ""; }, msg: "Tell us a little about your property or project." }
    ];
    var controlsFor = function (rule) {
      return rule.radio ? Array.prototype.slice.call(form.querySelectorAll('input[name="' + rule.radio + '"]')) : [$(rule.id)];
    };

    var setFieldError = function (rule, message) {
      var err = $(rule.id + "-error");
      controlsFor(rule).forEach(function (c) {
        /* Keep any help text in the description and add the error after it (Part B Field). */
        if (!c.hasAttribute("data-describedby")) c.setAttribute("data-describedby", c.getAttribute("aria-describedby") || "");
        var base = c.getAttribute("data-describedby");
        if (message) {
          c.setAttribute("aria-invalid", "true");
          if (!rule.radio) c.setAttribute("aria-describedby", (base ? base + " " : "") + rule.id + "-error");
        } else {
          c.removeAttribute("aria-invalid");
          if (!rule.radio) { if (base) c.setAttribute("aria-describedby", base); else c.removeAttribute("aria-describedby"); }
        }
      });
      err.textContent = message || "";
      err.hidden = !message;
    };

    var validate = function () {
      var errors = [];
      rules.forEach(function (rule) {
        var ok = rule.radio ? !!form.querySelector('input[name="' + rule.radio + '"]:checked') : rule.test($(rule.id).value);
        setFieldError(rule, ok ? "" : rule.msg);
        if (!ok) errors.push(rule);
      });
      return errors;
    };

    var value = function (name) { var el = form.elements[name]; return el ? String(el.value || "").trim() : ""; };
    var compose = function () {
      var interest = form.querySelector('input[name="interest"]:checked');
      return [
        "Enquiry for GEM",
        "Name: " + value("name"),
        "Organisation: " + (value("organisation") || "Not given"),
        "Email: " + value("email"),
        "Role: " + (value("role") || "Not given"),
        "Property or project: " + (value("property") || "Not given"),
        "About: " + (interest ? interest.value : ""),
        "",
        value("message")
      ].join("\n");
    };

    var clearDraft = function () {
      result.hidden = true;
      output.value = "";
      copyStatus.textContent = "";
      hasDraft = false;
    };

    /* GEM-04: any edit after preparing withdraws the draft, so a stale copy cannot be taken. */
    var onEdit = function (e) {
      if (e.target === trap || e.target === output) return;
      if (hasDraft) {
        clearDraft();
        draftStatus.textContent = "Your details changed. Prepare the enquiry again to update the draft.";
      }
    };
    form.addEventListener("input", onEdit);
    form.addEventListener("change", onEdit);

    form.addEventListener("submit", function () {
      clearDraft();
      draftStatus.textContent = "";
      var errors = validate();
      if (errors.length) {
        list.innerHTML = "";
        errors.forEach(function (rule) {
          var target = controlsFor(rule)[0];
          var li = document.createElement("li");
          var a = document.createElement("a");
          a.href = "#" + target.id;
          a.textContent = rule.msg;
          a.addEventListener("click", function (ev) { ev.preventDefault(); target.focus(); });
          li.appendChild(a);
          list.appendChild(li);
        });
        summary.hidden = false;
        controlsFor(errors[0])[0].focus();
        return;
      }
      summary.hidden = true;
      if (trap && trap.value) return; /* automated fill: do nothing */
      /* DELIVERY.endpoint is empty, so nothing is sent. */
      output.value = compose();
      hasDraft = true;
      result.hidden = false;
      result.focus();
    });

    form.addEventListener("reset", function () {
      rules.forEach(function (rule) { setFieldError(rule, ""); });
      summary.hidden = true;
      clearDraft();
      draftStatus.textContent = "";
      setTimeout(function () { $("f-name").focus(); }, 0);
    });

    copyBtn.addEventListener("click", function () {
      if (!hasDraft) return;
      var done = function () { copyStatus.textContent = "Copied to your clipboard."; };
      var fail = function () { output.focus(); output.select(); copyStatus.textContent = "Copy is not available here. The text is selected; copy it with your keyboard."; };
      try {
        if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(output.value).then(done, fail);
        else fail();
      } catch (err) { fail(); }
    });

    if (DELIVERY.endpoint) { /* reserved for an authorized connection; intentionally unused */ }

    /* Everything is installed: switch the form on. */
    unavailable.hidden = true;
    prepareButton.disabled = false;
  } catch (err) {
    /* Initialization failed: the button stays disabled and the unavailable notice stays visible. */
  }
})();
